#include "window.h"


int main(int argc, char** argv)
{
	WindowInit(argc, argv, 500, 500, "ICT289 Week 8 - 10 Labs - Bryce Standley 33046367");

	glutMainLoop();
	return 0;
}
