#include <GL/freeglut.h>

void WindowInit(int argc, char** argv, int windowWidth, int windowHeight, char* title);

void Render();

void Reshape(int w, int h);

void SetLighting();

void KeyboardInput(unsigned char key, int xVal, int yVa);